package com.snhu.inventory;

// Adds a new item to the database


import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class addActivity extends AppCompatActivity {
    EditText itemName;  // GUI name
    EditText itemQty;   // GUI quantity

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        // Get variable references to GUI objects
        Button updateBtn = findViewById(R.id.addButton);
        Button cancelBtn = findViewById(R.id.cancelButton);
        itemName = findViewById(R.id.itemNameText);
        itemQty = findViewById(R.id.qtyNumber);

        // Add click callbacks
        updateBtn.setOnClickListener(view -> addButtonClick());
        cancelBtn.setOnClickListener(view -> cancelButtonClick());
    }

    @Override
    protected void onStart()
    {
        super.onStart();

    }

    private void addButtonClick()
    {
        Item item;  // Item to add
        AppDatabase db = AppDatabase.getDatabase(getApplicationContext()); // Database instance


        // Get GUI fields
        String item_Name = itemName.getText().toString();
        Integer quantity = Integer.parseInt(itemQty.getText().toString());

        // Update item object
        item = new Item(item_Name,quantity);
        db.ItemDao().insert(item);   // Add new item

        setResult(RESULT_OK);
        finish();
    }

    private void cancelButtonClick()
    {
        setResult(RESULT_CANCELED);
        finish();
    }
}