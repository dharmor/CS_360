package com.snhu.inventory;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class settingsActivity extends AppCompatActivity {

    private SMS_Messenger smsMgr;
    private EditText phoneText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_settings);

        Button updateBtn = findViewById(R.id.updateBtn);
        Button cancelBtn = findViewById(R.id.cancelBtn);
        phoneText = findViewById(R.id.editTextPhone);

        // Add click callbacks
        updateBtn.setOnClickListener(view -> updateButtonClick());
        cancelBtn.setOnClickListener(view -> cancelButtonClick());

    }
    @Override
    protected void onStart()
    {
        // Retrieve phone number from SMS Messenger
        super.onStart();
        smsMgr = new SMS_Messenger();
        String phoneNumber = smsMgr.Get_SMS_Phone_Number(getApplicationContext());
        phoneText.setText(phoneNumber);
    }

    private void updateButtonClick()
    {
        // Save phone number to SMS Messenger
        smsMgr.Set_SMS_Phone_Number(getApplicationContext(),phoneText.getText().toString());
        setResult(RESULT_OK);
        finish();
    }

    private void cancelButtonClick()
    {
        setResult(RESULT_CANCELED);
        finish();
    }
}