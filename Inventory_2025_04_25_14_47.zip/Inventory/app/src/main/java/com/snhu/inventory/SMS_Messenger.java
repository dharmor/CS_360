package com.snhu.inventory;


import static android.Manifest.permission.SEND_SMS;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;

import androidx.core.content.ContextCompat;

public class SMS_Messenger {

    public String Get_SMS_Phone_Number(Context context)
    {
        // Get values in myprefs.xml
        SharedPreferences sharedPref = context.getSharedPreferences("myprefs", Context.MODE_PRIVATE);
        String mString = sharedPref.getString("SMS_Phone","0");

        return mString;

    }

    public void Set_SMS_Phone_Number(Context context, String sms_phone)
    {
        // Save values in myprefs.xml
        SharedPreferences namedSharedPref = context.getSharedPreferences("myprefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = namedSharedPref.edit();
        editor.putString("SMS_Phone", sms_phone);
        editor.apply();



    }

public boolean Send(Context context,String msg)
{
    boolean success = false;

    SharedPreferences sharedPref = context.getSharedPreferences("myprefs", Context.MODE_PRIVATE);
    String mString = sharedPref.getString("SMS_Phone","0");


    return success;

}

    public boolean checkPermission(Context appContext) {

        //Check SMS permission status
        int result = ContextCompat.checkSelfPermission(appContext, SEND_SMS);

        return result == PackageManager.PERMISSION_GRANTED;
    }
}
