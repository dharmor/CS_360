package com.snhu.inventory;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {User.class,Item.class},version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract com.snhu.inventory.UserDao UserDao();
    public abstract com.snhu.inventory.ItemDao ItemDao();
    private static AppDatabase InventoryDB;
    public static final String TAG = "OPENINFO"; /* added */
    private static final int NUMBER_OF_THREADS = 4;
    /* not used for demo */

    static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    static AppDatabase getDatabase(final Context context) {
        if (InventoryDB == null) {
            synchronized (AppDatabase.class) {
                if (InventoryDB == null) {
                    InventoryDB = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "inventory_database").allowMainThreadQueries().build();
                }
            }
        }
        return InventoryDB;

    }

    public void deleteDatabase()
    {
        InventoryDB.clearAllTables();
    }

    /* Will close DB if it is open */
    public void cleanUp(){
        if (InventoryDB != null && InventoryDB.isOpen()) {
            InventoryDB.close();
        }
        InventoryDB = null;
    }
}
