package com.snhu.inventory;

import static android.Manifest.permission.SEND_SMS;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 200;
    AppDatabase db;
    UserDao dao;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        final EditText usernameEditText = findViewById(R.id.username);
        final EditText passwordEditText = findViewById(R.id.password);
        final Button loginButton = findViewById(R.id.signIn);
        final Button registerButton = findViewById(R.id.register);



        // final ProgressBar loadingProgressBar = findViewById(R.id.loading);

        loginButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                onSignIn(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());
            }
        });

        usernameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (loginCheck(usernameEditText.getText().toString(), passwordEditText.getText().toString())) {
                    loginButton.setEnabled(false);
                    registerButton.setEnabled(false);
                } else {
                    loginButton.setEnabled(true);
                    registerButton.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        passwordEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (loginCheck(usernameEditText.getText().toString(), passwordEditText.getText().toString())) {
                    loginButton.setEnabled(false);
                    registerButton.setEnabled(false);
                } else {
                    loginButton.setEnabled(true);
                    registerButton.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // loadingProgressBar.setVisibility(View.VISIBLE);
                onSignIn(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  loadingProgressBar.setVisibility(View.VISIBLE);
                onRegister(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());


            }
        });
        // Check if app has SMS permissions if not make request
        if(!checkPermission())
            requestPermission();


    }


    private void onSignIn(String userName, String password) {

        User currentUser;

        final TextView infoText = findViewById(R.id.infoText);

        userName = userName.toLowerCase().trim();

        infoText.setText("");

        db = AppDatabase.getDatabase(getApplicationContext());

        currentUser = db.UserDao().findByName(userName);

        if(currentUser != null) {
            if (currentUser.userName.toLowerCase().trim().equals(userName.toString())) {
                if (currentUser.password.equals(password)) {
                    // Toast
                    Toast.makeText(getApplicationContext(), "Welcome " + userName, Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(this, InventoryActivity.class);
                    startActivity(intent);
                } else {
                    infoText.setText("Password invalid for user  " + userName);
                    infoText.setTextColor(Color.RED);
                }
            } else {
                infoText.setText("User name " + userName + " not found. Please register.");
                infoText.setTextColor(Color.RED);
            }
        }
        else {
            infoText.setText("User name " + userName + " not found. Please register.");
            infoText.setTextColor(Color.RED);
        }
    }

    private void onRegister(String userName, String password) {


        User currentUser;

        final TextView infoText = findViewById(R.id.infoText);
        infoText.setText("");

        userName = userName.toLowerCase().trim();

        db = AppDatabase.getDatabase(this.getApplicationContext());

        currentUser = db.UserDao().findByName(userName);
        if(currentUser != null) {
            if (currentUser.userName.toLowerCase().trim().equals(userName.toLowerCase().trim()))
            {
                infoText.setText("User " + userName + " already exists.");
            } else {
                currentUser.userName = userName;
                currentUser.password = password;
                db.UserDao().insertAll(currentUser);
                infoText.setText("User name " + userName + " is now registered. Please Log in.");
                infoText.setTextColor(Color.BLACK);
            }
        }
        else
        {
            currentUser = new User();
            currentUser.userName = userName;
            currentUser.password = password;
            db.UserDao().insertAll(currentUser);
            infoText.setText("User name " + userName + " is now registered. Please Log in.");
            infoText.setTextColor(Color.BLACK);
        }
    }

    private boolean loginCheck(String Email, String Password) {

        boolean State = false;
        // Enforce rules
        // Email address must have a @
        // Password must be 6 characters or more
        if ((Email.contains("@")) && (Password.length() > 5)) {
            State = true;
        }

        return !State;
    }

    private boolean checkPermission() {

        //Check SMS permission status
        int result = ContextCompat.checkSelfPermission(getApplicationContext(), SEND_SMS);

        return result == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {

        // Request permission from user
        ActivityCompat.requestPermissions(this, new String[]{SEND_SMS}, PERMISSION_REQUEST_CODE);

    }
}