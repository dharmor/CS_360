package com.snhu.inventory;

import android.os.Bundle;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class UpdateActivity extends AppCompatActivity {
    private AppDatabase db;
    private TextView itemName;
    private Item item;
    private EditText itemQty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_update);
        Button updateBtn = findViewById(R.id.addButton);
        Button cancelBtn = findViewById(R.id.cancelButton);

        // Add click callbacks
        updateBtn.setOnClickListener(view -> updateButtonClick());
        cancelBtn.setOnClickListener(view -> cancelButtonClick());
        db = AppDatabase.getDatabase(getApplicationContext());

    }

    @Override
    protected void onStart()
    {
        super.onStart();
        itemName = findViewById(R.id.itemName);
        itemQty = itemQty = findViewById(R.id.qtyNumber);

        Intent intent = getIntent();
        int itemId = intent.getIntExtra("item", -1);

       item = db.ItemDao().findByID(itemId);

       itemName.setText(item.itemName);
       itemQty.setText(String.valueOf(item.quantity));


    }
    private void cancelButtonClick(){
        setResult(RESULT_CANCELED);
        finish();
    }

    private void updateButtonClick(){


        // Send back OK result
        if(Integer.parseInt(itemQty.getText().toString()) != 0) {
            item.quantity = Integer.parseInt(itemQty.getText().toString());
            db.ItemDao().updateItem(item);
        }
        else
        {
            item.quantity = Integer.parseInt(itemQty.getText().toString());
            db.ItemDao().updateItem(item);
            SMS_Messenger sms_messenger = new SMS_Messenger();
            if(sms_messenger.checkPermission(getApplicationContext()))
            {
                sms_messenger.Send(getApplicationContext(),item.itemName+" is out of stock");
            }
            else
            {
                Toast.makeText(getApplicationContext(), "Could not send SMS message. No permission", Toast.LENGTH_LONG).show();
            }
        }
        setResult(RESULT_OK);
        finish();

    }


    }