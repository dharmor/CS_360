package com.snhu.inventory;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Fts4;
import androidx.room.PrimaryKey;

// Use `@Fts3` only if your app has strict disk space requirements or if you
// require compatibility with an older SQLite version.
@Fts4
@Entity(tableName = "inventory")
public class Item {
    // Specifying a primary key for an FTS-table-backed entity is optional, but
    // if you include one, it must use this type and column name.



    public Item(String itemName, Integer quantity) {
        this.itemName = itemName;
        this.quantity = quantity;
    }
    @ColumnInfo(name = "rowid")
    @PrimaryKey(autoGenerate = true)
    public int rowid;

    @ColumnInfo(name = "Item")
    public String itemName;


    @ColumnInfo(name = "Quantity")
    public Integer quantity;
}