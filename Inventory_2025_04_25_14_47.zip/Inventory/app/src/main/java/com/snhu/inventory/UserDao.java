package com.snhu.inventory;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.snhu.inventory.User;

import java.util.List;

@Dao
public interface UserDao {


    @Query("SELECT *,`rowid` FROM users")
    List<User> getAll();

    /*
    @Query("SELECT * FROM users WHERE rowid IN (:rowid)")
    List<User> loadAllByIds(int[] rowid);
*/
    @Query("SELECT *, `rowid` FROM users WHERE userName = :userName LIMIT 1")
    User findByName(String userName);

    @Insert
    void insertAll(User... users);

    @Delete
    void delete(User user);
    @Update
    void  updateUsers(User... user);
}