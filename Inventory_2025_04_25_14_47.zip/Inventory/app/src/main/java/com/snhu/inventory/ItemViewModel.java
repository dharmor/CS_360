package com.snhu.inventory;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class ItemViewModel extends AndroidViewModel {
    private ItemRepository itemRepository;
    private final LiveData<List<Item>> listLiveData;

    public ItemViewModel(Application application) {
        super(application);
       itemRepository = new ItemRepository(application);
        listLiveData = itemRepository.getAllitems();
    }

    public LiveData<List<Item>> getAllItemsFromVm() {
        return listLiveData;
    }

    public void insertItem(Item item) {
        itemRepository.insertItem(item);
    }
}