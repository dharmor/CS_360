package com.snhu.inventory;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class ItemRepository {
    AppDatabase  inventoryRoomDatabase;
    ItemDao itemDao;
    private LiveData<List<Item>> listItems;

    public ItemRepository(Application application) {
        inventoryRoomDatabase = AppDatabase.getDatabase(application);
        itemDao = inventoryRoomDatabase.ItemDao();
        listItems = itemDao.getItem();
    }

    public void insertItem(Item item) {
        AppDatabase.databaseWriteExecutor.execute(() -> itemDao.insert(item));
    }

    public LiveData<List<Item>> getAllitems() {
        return listItems;
    }
}