package com.snhu.inventory;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;
import android.widget.Button;
import android.widget.Toast;

public class InventoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.inventory_list);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

           final Button settingsButton = findViewById(R.id.settingsBtn);
            settingsButton.setOnClickListener(buttonView -> {

                OnSettings();
            });

            final Button addButton = findViewById(R.id.buttonAdd);
            addButton.setOnClickListener(buttonView -> {
              onAddBtn();

            });
            return insets;
        });
    }


    @Override
    protected void onStart()
    {
        super.onStart();
        createTable();


    }

    private void OnSettings()
    {
        Intent intent = new Intent(this, settingsActivity.class);
        startActivity(intent);
    }

    // Create table of each item in database
    private void createTable()
    {


        TableLayout t1 = null;

        TableLayout tl = (TableLayout) findViewById(R.id.main_table);
        //Clear table of all rows
        int count = tl.getChildCount();
        if (count > 0)
            tl.removeViews(0, Math.max(0,  tl.getChildCount() ));
        // Create header row
        TableRow tr_head = new TableRow(this);
        tr_head.setId(100);
        ColorDrawable colorDrawable = new ColorDrawable(ContextCompat.getColor(this, R.color.md_theme_onPrimaryContainer));
        tr_head.setBackground(colorDrawable);
        tr_head.setLayoutParams(new TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT));

        TextView label_item = new TextView(this);
        TableRow.LayoutParams params = new TableRow.LayoutParams(100, TableRow.LayoutParams.WRAP_CONTENT,1);
        params.column = 0;
        params.gravity = Gravity.CENTER ;
        params.width = 25;
        params.rightMargin = 20;
        params.leftMargin = 10;

        label_item.setLayoutParams(params);
        label_item.setId(101);
        label_item.setText("ITEM");

        label_item.setTextColor(Color.WHITE);
        label_item.setPadding(5, 5, 5, 5);
        tr_head.addView(label_item);// add the column to the table row here

        TextView label_quantity = new TextView(this);
        params = new TableRow.LayoutParams(100, TableRow.LayoutParams.WRAP_CONTENT,1);
        params.column = 1;
        params.gravity = Gravity.CENTER | Gravity.BOTTOM;
        params.width = 50;
        params.rightMargin = 50;
        params.weight = 1;
        label_quantity.setLayoutParams(params);
        label_quantity.setId(102);// define id that must be unique
        label_quantity.setText("QUANTITY"); // set the text for the header
        label_quantity.setTextColor(Color.WHITE); // set the color

        label_quantity.setPadding(5, 5, 5, 5); // set the padding (if required)
        tr_head.addView(label_quantity); // add the column to the table row here
        tl.addView(tr_head, new TableLayout.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT));

        // Get database instance
        AppDatabase db = AppDatabase.getDatabase(getApplicationContext());

        Integer id;
        id = 300;
        List<Item> m_list;
        m_list = db.ItemDao().getAll();  // Get a list of all database items
        // Add each item to the table
        for (Item item : m_list)
        {
            TableRow tr_row = new TableRow(this);
            tr_row.setId(id);
            id = id + 1;
            tr_row.setBackgroundColor(Color.GRAY);
            tr_row.setLayoutParams(new TableRow.LayoutParams(
                    TableRow.LayoutParams.MATCH_PARENT,
                    TableRow.LayoutParams.WRAP_CONTENT));
            // Item Name
            TextView item_name = new TextView(this);
            params = new TableRow.LayoutParams(100, TableRow.LayoutParams.WRAP_CONTENT,1);
            params.column = 0;
            params.gravity = Gravity.CENTER ;
            params.width = 25;
            params.rightMargin = 20;
            params.leftMargin = 10;

            item_name.setLayoutParams(params);
            item_name.setId(id);
            id = id + 1;
            item_name.setText(item.itemName);

            item_name.setTextColor(Color.WHITE);
            item_name.setPadding(5, 5, 5, 5);
            tr_row.addView(item_name);// add the column to the table row here

            // Item quantity
            TextView item_quantity = new TextView(this);
            params = new TableRow.LayoutParams(100, TableRow.LayoutParams.WRAP_CONTENT,1);
            params.column = 1;
            params.gravity = Gravity.CENTER | Gravity.BOTTOM;
            params.width = 50;
            params.rightMargin = 50;
            params.weight = 1;
            item_quantity.setLayoutParams(params);
            item_quantity.setId(id);// define id that must be unique
            id = id + 1;
            item_quantity.setText(String.valueOf(item.quantity)); // set the text for the header
            item_quantity.setTextColor(Color.WHITE); // set the color
            item_quantity.setPadding(5, 5, 5, 5); // set the padding (if required)
            tr_row.addView(item_quantity); // add the column to the table row here

            // Item update button
            Button item_Button = new Button (this);
            params = new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT,1);
            params.column = 3;
            params.gravity = Gravity.CENTER | Gravity.BOTTOM;
            params.width = 50;
            params.rightMargin = 50;
            params.weight = 1;
            params.setMargins( 0, 0, 0, 10 );
            item_Button.setId(id);
            id = id + 1;
            item_Button.setTag(item.rowid);
            item_Button.setLayoutParams(params);
            item_Button.setBackground(colorDrawable);
            item_Button.setTextColor( Color.WHITE );
            item_Button.setGravity( Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL );
            item_Button.setText( "Update");
            item_Button.setOnClickListener(buttonView -> {
                // Create fragment arguments containing the selected band ID

                Intent intent = new Intent(this, UpdateActivity.class);
                intent.putExtra("item", (int) buttonView.getTag());
                startActivity(intent);

                createTable();


            });
            tr_row.addView(item_Button);
            // Item Delete button
            item_Button = new Button (this);
            params = new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT,1);
            params.column = 3;
            params.gravity = Gravity.CENTER | Gravity.BOTTOM;
            params.width = 50;
            params.rightMargin = 50;
            params.weight = 1;
            params.setMargins( 0, 0, 0, 10 );
            item_Button.setId(id);
            id = id + 1;
            item_Button.setTag(item.rowid);
            item_Button.setLayoutParams(params);
            item_Button.setBackground(colorDrawable);
            item_Button.setTextColor( Color.WHITE );
            item_Button.setGravity( Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL );
            item_Button.setText( "Delete");
            item_Button.setOnClickListener(buttonView -> {
                // Create fragment arguments containing the selected band ID
                int selectedItemId = (int) buttonView.getTag();
                db.ItemDao().deleteById(selectedItemId);
                createTable();

            });


            tr_row.addView(item_Button);

            tl.addView(tr_row, new TableLayout.LayoutParams(
                    TableRow.LayoutParams.MATCH_PARENT,
                    TableRow.LayoutParams.WRAP_CONTENT));

        }

    }

    private void onAddBtn()
    {
        Intent intent = new Intent(this, addActivity.class);
        startActivity(intent);

        createTable();
    }


}